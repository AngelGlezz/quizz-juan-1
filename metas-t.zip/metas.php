<?php
	$metas = array(
		"Messi" => array(
			"title" => "¿messi o cr7? la verdad",
			"description" => "¡Eres un D10S como Messi!",
			"image" => "images/metas/0.png" 
		),
		"Bicho" => array(
			"title" => "¿messi o cr7? la verdad",
			"description" => "¡Siuuuuu! ¡Eres como 'El Comandante'!",
			"image" => "images/metas/1.png" 
		)
	);